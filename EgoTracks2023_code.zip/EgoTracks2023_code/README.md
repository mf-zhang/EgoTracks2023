# EgoTracks 

## Install
```sh
pip install detectron2 -f https://dl.fbaipublicfiles.com/detectron2/wheels/cu101/torch1.8/index.html

pip install torch==1.8.1+cu101 torchvision==0.9.1+cu101 torchaudio==0.8.1 -f https://download.pytorch.org/whl/torch_stable.html

pip install opencv-python av pandas decord ensemble-boxes
```


## Data preparation
Please follow https://github.com/EGO4D/episodic-memory/tree/main/EgoTracks to download and process data, and finetune pre-trained models.


## Infer challenge set and submit challenge result
Please change the settings in `test.sh` and then run:
```sh
sh test.sh
```

Please refer to our technical report and visit the GitHub repository at https://github.com/ZFTurbo/Weighted-Boxes-Fusion for more information on model ensembling.

## Reference
https://github.com/EGO4D/episodic-memory/tree/main/EgoTracks

