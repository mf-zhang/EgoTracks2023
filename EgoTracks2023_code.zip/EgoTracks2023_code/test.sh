export PYTHONPATH="/home/acf15418sy/EgoTracks2023" # Project address

# Run the first model
python tools/train_net.py \
--num-gpus 2 --eval-only \
MODEL.WEIGHTS /path/to/STARKST_1.pth.tar \
OUTPUT_DIR /path/to/results/ \
EVAL.EGO4DLT.ANNOTATION_PATH /home/acf15418sy/ego4d_data/v2/egotracks/egotracks_challenge_test_unannotated.json \
EVAL.EGO4DLT.DATA_DIR /groups/gcb50205/share/dataset/ego4d/egotrack_clips_frames/test