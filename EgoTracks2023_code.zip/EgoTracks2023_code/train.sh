python tools/train_net.py \
--num-gpus 4 \
MODEL.WEIGHTS /home/acf15418sy/yyWorkspace/episodic-memory/EgoTracks/STARKST_ep0001.pth.tar \
\
OUTPUT_DIR /home/acf15418sy/yyWorkspace/episodic-memory/EgoTracks/zmf_train_ckpt2/res/stark_finetune_Ego4DLTT \
TRAIN_STAGE_1.EPOCH 10 \
TRAIN_STAGE_1.LR_DROP_EPOCH 8 \
TRAIN_STAGE_1.NUM_WORKER 10 \
TRAIN_STAGE_2.EPOCH 1 \
TRAIN_STAGE_2.NUM_WORKER 10 \
DATA.TRAIN.DATASETS_NAME "[\"EGO4DLTT\"]" \
DATA.TRAIN.DATASETS_RATIO "[1]" \
DATA.VAL.DATASETS_NAME "[\"EGO4DLTT\"]" \
DATA.VAL.DATASETS_RATIO "[1]" \
DATA.EGO4DLTT_ANNOTATION_PATH  /home/acf15418sy/ego4d_data/v2/egotracks/egotracks_train.json \
DATA.EGO4DLTT_DATA_DIR /groups/gcb50205/share/dataset/ego4d/v1/clips_full/v2/clips/
